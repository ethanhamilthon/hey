import sys

from rich import box
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.live import Live

from core.chat import ChatProvider
from heyai.system import SYSTEM_PROMPT
from shared.history import ChatHistory, ChatMessage, history_from_file, history_to_file


def main():
    # load json history
    chat_history = history_from_file("/Users/erdanaerbol/.heyai/history.json")
    if not chat_history:
        print("Some error occurred while loading history")
        return

    # call llm api
    text = " ".join(sys.argv[1:])
    if len(sys.argv) == 1:
        print("No text provided")
        return

    first_arg = sys.argv[1]
    if first_arg == "--new":
        print("New conversation")
        chat_history = ChatHistory(messages=[])
        if len(sys.argv) == 2:
            history_to_file(chat_history, "/Users/erdanaerbol/.heyai/history.json")
            return

    chat_history.messages.append(ChatMessage(role="user", content=text))
    chat = ChatProvider(
        "AIzaSyB6lVYoEf3M1UgcAsEdt37qkvsaaQvG4Ac", chat_history, SYSTEM_PROMPT
    )
    response = chat.simple_chat()

    # print response as markdown
    buffer = ""
    md = Markdown(buffer, code_theme="dracula")
    panel = Panel(md, padding=(1, 4), box=box.HORIZONTALS)
    with Live(panel, console=Console(), refresh_per_second=10) as live:
        for chunk in response:
            buffer += chunk.text or ""
            md = Markdown(buffer, code_theme="dracula")
            panel = Panel(md, padding=(1, 4), box=box.HORIZONTALS)
            live.update(panel)

    # save json history
    chat_history.messages.append(ChatMessage(role="assistant", content=buffer))
    history_to_file(chat_history, "/Users/erdanaerbol/.heyai/history.json")


if __name__ == "__main__":
    main()
