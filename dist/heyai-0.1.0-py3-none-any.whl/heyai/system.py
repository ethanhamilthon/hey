SYSTEM_PROMPT = """
You are a helpful assistant.
"""
